package Visao;

import javax.swing.JOptionPane;

public class ComputadorMain {

    public static void main(String[] args) {
        // Mensagem inicial
        JOptionPane.showMessageDialog(null, "Bem-vindo à montagem de computador!");

        // Criando um StringBuilder para armazenar as informações da pilha
        StringBuilder pilhaInfo = new StringBuilder();

        // Empilhando as peças
        pilhaInfo.append("Empilhando todas as peças...\n\n");
        empilharPecas(pilhaInfo);

        // Exibindo a pilha
        JOptionPane.showMessageDialog(null, pilhaInfo.toString(), "Pilha Montada", JOptionPane.PLAIN_MESSAGE);

        // Desempilhando as peças
        StringBuilder desempilharInfo = new StringBuilder();
        desempilharInfo.append("Desempilhando todas as peças...\n\n");
        desempilharPecas(desempilharInfo);

        // Exibindo a pilha final em outra janela
        JOptionPane.showMessageDialog(null, desempilharInfo.toString(), "Pilha Desmontada", JOptionPane.PLAIN_MESSAGE);
    }

    // Método para empilhar as peças
    public static void empilharPecas(StringBuilder pilhaInfo) {
        pilhaInfo.append("Gabinete\n");
        pilhaInfo.append("Placa mãe\n");
        pilhaInfo.append("Fonte do PC\n");
        pilhaInfo.append("Memórias\n");
        pilhaInfo.append("Processador\n");
        pilhaInfo.append("Placa de vídeo\n");
    }

    // Método para desempilhar as peças
    public static void desempilharPecas(StringBuilder pilhaInfo) {
        pilhaInfo.append("Placa de vídeo\n");
        pilhaInfo.append("Processador\n");
        pilhaInfo.append("Memórias\n");
        pilhaInfo.append("Fonte do PC\n");
        pilhaInfo.append("Placa mãe\n");
        pilhaInfo.append("Gabinete\n");
    }
}