package Modelagem;

public class Pecas {

	
	// atributos //
	
	private int codigo; 
	private String nome;     
	
	
	// gets e set //
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	//  tostring //
	
	public String toString() {
		return this.nome;
}

	
	// construtor // 
	
	public Pecas(int codigo, String nome) {
		this.nome = nome;
		this.codigo = codigo;
}

	// equals //
	
	public boolean equals (Object p) {
		return ((Pecas)p).getNome().equals(this.getNome());

}
}

	
	

