package Negocio;

import Modelagem.Pecas;

public class Montando {
	
	private int tamanhoPilha = 7;
	private Pecas [] computador;
	private int ponteiro;
	
	
	public Montando() {
		this.computador = new Pecas[tamanhoPilha];
		this.ponteiro = 0;
}


	public Pecas[] getComputador() {
		return computador;
	
}

	public void setComputador(Pecas[] computador) {
		this.computador = computador;
}
	
	
	
	public void montar (Pecas pecas) {
		System.out.println("Montando a parte..." + pecas.getNome()+"");
	
		
	movimentandoPilha();
	
		computador[0]= pecas;
		ponteiro ++;
		
	
	printComputador();
}
	public void movimentandoPilha() {
		for (int i=0; i<ponteiro; i++) {
			if(ponteiro+i<computador.length) {
				computador[ponteiro-i]=computador[ponteiro-i-1];
			}
		}
					computador[0]=null;
	}	
	

		public void printComputador () {
			String retorno= " ";
				for(int i=0;i<computador.length;i++) {
					retorno += String.format("\t\t [%s] => %s",i,computador[i] != null? computador[i].getNome():"-------");
}
						System.out.println(retorno);
}	
	
		public void movimentarDespilhamento() {
		    for (int i=0;i<ponteiro;i++) {
		        if(i+1<computador.length) {
		        	computador[i]=computador[i+1];
		        }
		    }
		    computador[ponteiro-1] = null;
		}
		public void desimpilhar(Pecas pecas) {
			System.out.println("Desmontando a parte...\n" + pecas.getNome());
			
			movimentarDespilhamento();
			
			ponteiro--;
			
			printComputador();
		}
}	